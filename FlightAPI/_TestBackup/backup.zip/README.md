# Comprehensive-UFT-API-test-against-FlightAPI
This test uses most of the core functionality within  UFT API testing

The flow: Get Flights Array[1], Create Order Loop based on parameters, Get All Newly added Flight Orders Array, Delete all new Orders Created. 
Includes the following standard activities:

•	System Environment Variable

•	Date/Time

•	For Loop

•	Open DB Connection

•	Checkpoints

• DB Query

• Concatenate String

• Custom Report Message

• Close BD Connection



Many thanks for Andrew Lozoya for his initial work on this.
